console.log("Jete Money Saving Project loaded");
// ระบบจัดการธุรกรรม บัญชี หมวดหมู่ งบประมาณ จะเขียนในส่วนนี้
